# praktikum3.1

A Pen created on CodePen.

Original URL: [https://codepen.io/Nailarizqya/pen/yyeMmoR](https://codepen.io/Nailarizqya/pen/yyeMmoR).

